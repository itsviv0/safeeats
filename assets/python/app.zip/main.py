import json
import os


# Define the preprocessing function directly in this file
def preprocess_text(ocr_text):
    import re

    def clean_text(text):
        text = text.lower()
        text = re.sub(r"^.*?ingredients:", "", text, flags=re.IGNORECASE).strip()
        text = re.sub(r"ingredients:", "", text, flags=re.IGNORECASE)
        text = re.sub(r"[^a-zA-Z, ]", "", text)
        text = re.sub(r"\s+", " ", text).strip()
        return text

    def split_ingredients(text):
        ingredients = text.split(",")
        ingredients = [ing.strip() for ing in ingredients if ing.strip()]
        return ingredients

    cleaned_text = clean_text(ocr_text)
    ingredients_list = split_ingredients(cleaned_text)
    return ingredients_list


def main():
    # Get input text from environment variable
    extracted_text = os.environ.get("INPUT_TEXT", "")

    if not extracted_text:
        print(json.dumps(["Error: No text provided"]))
        return

    try:
        # Use the defined function instead of loading from pickle
        result = preprocess_text(extracted_text)

        # Return the result as JSON
        print(json.dumps(result))
    except Exception as e:
        print(json.dumps([f"Error: {str(e)}"]))


if __name__ == "__main__":
    main()
